
#include "stm32f4xx_hal.h"

#define VECTOR_LENGTH 2048

extern const int16_t theFunction[VECTOR_LENGTH];
